-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2023 at 10:01 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userregistration`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `_date` date NOT NULL,
  `_time` time(6) NOT NULL,
  `_from` varchar(100) NOT NULL,
  `_to` varchar(100) NOT NULL,
  `ticket` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `fullname`, `email`, `phonenumber`, `_date`, `_time`, `_from`, `_to`, `ticket`) VALUES
(5, 'maryam talba', 'maryamtalba@gmail.com', '07066218753', '2024-12-02', '01:00:00.000000', 'Damaturu', 'Nguru', 2),
(7, 'ALIYU SALLAU', 'aliyusallau2018@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(11, 'maryam talba', 'aliyusallau2018@gmail.com', '07066218753', '2023-01-01', '01:00:00.000000', 'Damaturu', 'Nguru', 4),
(13, 'musa sabo', 'musasabogumel@gmsil.com', '09074233199', '2023-01-31', '01:00:00.000000', 'Damaturu', 'Nguru', 1),
(14, 'musa sabo', 'musasabogumel@gmail.com', '09074233199', '2023-01-31', '01:00:00.000000', 'Damaturu', 'Nguru', 1),
(17, 'kabiru gambo', 'kabiru123@gmail.com', '08030749342', '2023-01-31', '01:00:00.000000', 'Damaturu', 'Nguru', 3),
(20, 'Aliyu Sallau', 'aliyusallau2018@gmail.com', '07066218753', '2019-04-03', '10:00:00.000000', 'Nguru', 'Damaturu', 1),
(21, 'Aliyu Sallau', 'aliyuibrahimsallau@gmail.com', '07066218753', '2019-04-03', '10:00:00.000000', 'Nguru', 'Damaturu', 1),
(22, 'muhammad musa', 'jaafarsallau2001@gmail.com', '09068604584', '0007-06-05', '06:05:00.000000', 'Damaturu', 'Nguru', 1),
(31, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '23:59:00.000000', 'Damaturu', 'Nguru', 3),
(32, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '23:59:00.000000', 'Damaturu', 'Nguru', 3),
(33, 'musa sabo', 'jaafarsallau2001@gmail.com', '09068604584', '2022-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 1),
(34, 'musa sabo', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(35, 'adamu goni', 'jaafarsallau2001@gmail.com', '08030749342', '2023-12-31', '01:00:00.000000', 'Damaturu', 'Nguru', 1),
(36, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(37, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(38, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Nguru', 'Nguru', 3),
(39, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-05-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(40, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(41, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2022-12-31', '12:58:00.000000', 'Damaturu', 'Nguru', 1),
(42, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 1),
(43, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 1),
(44, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(45, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2022-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(46, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2022-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(47, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(48, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(49, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '23:59:00.000000', 'Damaturu', 'Nguru', 2),
(50, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(51, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 10),
(52, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 10),
(53, 'Yushau elsunais', 'yelsunais2014@gmail.com', '08030749342', '2023-12-31', '00:00:00.000000', 'Damaturu', 'Nguru', 1),
(54, 'maryam talba', 'jaafarsallau2001@gmail.com', '08030749342', '2023-12-01', '01:59:00.000000', 'Damaturu', 'Nguru', 5),
(55, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(56, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Nguru', 'Damaturu', 1),
(57, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '00:59:00.000000', 'Damaturu', 'Nguru', 2),
(58, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(59, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '00:59:00.000000', 'Damaturu', 'Nguru', 3),
(60, 'jaafar sallau', 'maryamtalba@gmail.com', '09068604584', '2015-01-01', '13:00:00.000000', 'Damaturu', 'Nguru', 5),
(61, 'musa sabo', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-01', '01:00:00.000000', 'Damaturu', 'Nguru', 5),
(62, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(63, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(64, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-05-31', '12:58:00.000000', 'Damaturu', 'Nguru', 2),
(65, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-01', '02:00:00.000000', 'Damaturu', 'Nguru', 2),
(66, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', '4', 2),
(67, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(68, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2023-12-31', '00:59:00.000000', 'Damaturu', 'Nguru', 2),
(69, 'hajara nura', 'hajara123@gmail.com', '07050700903', '2023-12-03', '02:19:00.000000', 'Damaturu', 'Nguru', 2),
(70, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(71, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2019-02-03', '02:02:00.000000', 'Damaturu', 'Nguru', 2),
(72, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-01', '01:00:00.000000', 'Damaturu', 'Nguru', 4),
(73, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2022-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 4),
(74, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 6),
(75, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 5),
(76, 'sallau adamu', 'sallaukowanaka1@gmail.com', '08030749342', '2023-01-03', '13:00:00.000000', 'Damaturu', 'Nguru', 3),
(77, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2022-12-02', '01:00:00.000000', 'Damaturu', 'Nguru', 5),
(78, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(79, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(80, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-30', '12:59:00.000000', 'Damaturu', 'Nguru', 2),
(81, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-03', '02:00:00.000000', 'Damaturu', 'Nguru', 3),
(82, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(83, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(84, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 5),
(85, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2025-02-02', '01:00:00.000000', 'Damaturu', 'Nguru', 6),
(86, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2025-02-02', '01:00:00.000000', 'Damaturu', 'Nguru', 6),
(87, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2025-02-02', '01:00:00.000000', 'Damaturu', 'Nguru', 6),
(88, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(89, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 1),
(90, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(91, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'Damaturu', 'Nguru', 3),
(92, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-03-31', '12:59:00.000000', 'damaturu', 'nguru', 2),
(93, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:58:00.000000', 'damaturu', 'nguru', 3),
(94, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '23:59:00.000000', 'damaturu', 'nguru', 3),
(95, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '07066218753', '2023-12-31', '12:59:00.000000', 'damaturu', 'nguru', 4),
(96, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', '2022-12-31', '12:59:00.000000', 'damaturu', 'nguru', 5),
(97, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:59:00.000000', 'damaturu', 'nguru', 4),
(98, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:58:00.000000', 'damaturu', 'nguru', 4),
(99, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '12:58:00.000000', 'damaturu', 'nguru', 4),
(100, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', '2023-12-31', '23:59:00.000000', 'damaturu', 'nguru', 2);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(20) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  `Usermessage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `fullname`, `email`, `phonenumber`, `Usermessage`) VALUES
(1, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', ''),
(2, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', ''),
(3, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', ''),
(4, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', ''),
(5, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 'hi'),
(6, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 'hi'),
(7, 'Kabirru Gambo ', 'frabiubakabe@gmail.com', '09077373553', 'jk'),
(8, 'Kabirru Gambo ', 'frabiubakabe@gmail.com', '09077373553', 'jk'),
(9, 'Kabirru Gambo ', 'frabiubakabe@gmail.com', '09077373553', 'jk'),
(10, 'Kabirru Gambo ', 'frabiubakabe@gmail.com', '09077373553', 'jk'),
(11, 'jaafar sallau', 'sallaukowanaka1@gmail.com', '09068604584', 'jk'),
(12, 'Kabirru Gambo ', 'jaafarsallau2001@gmail.com', '09077373553', 'hi you'),
(13, 'nasiru kabiru', 'nasiru123@gmail.com', '07066218753', 'hi there!'),
(14, 'nasiru kabiru', 'nasiru123@gmail.com', '07066218753', 'hi there!'),
(15, 'nasiru kabiru', 'nasiru123@gmail.com', '07066218753', 'hi there!'),
(16, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '09068604584', 'hi'),
(17, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '09068604584', 'hi'),
(18, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '09068604584', 'hi'),
(19, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '09068604584', 'hi'),
(20, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '09068604584', 'hi'),
(21, 'idi mudi', 'idi123@gmail.com', '07066218753', 'hi man'),
(22, 'idi mudi', 'idi123@gmail.com', '07066218753', 'hi man'),
(23, 'yusuf sadi', 'frabiubakabe@gmail.com', '09077373553', 'yoyo'),
(24, 'yusuf sadi', 'frabiubakabe@gmail.com', '09077373553', 'yoyo'),
(25, 'yusuf sadi', 'frabiubakabe@gmail.com', '09077373553', 'yoyo'),
(26, 'yusuf sadi', 'frabiubakabe@gmail.com', '09077373553', 'yoyo'),
(27, 'umar musa', 'musa123', '07066218753', '1234'),
(28, 'umar musa', 'musa123', '07066218753', '1234'),
(29, 'umar musa', 'musa123', '07066218753', '1234'),
(30, 'umar musa', 'musa123', '07066218753', '1234'),
(31, 'umar musa', 'musa123', '07066218753', 'man'),
(32, 'umar musa', 'musa123', '07066218753', 'man'),
(33, 'umar musa', 'musa123', '07066218753', 'man'),
(34, 'Kabirru Gambo ', 'jaafarsallau2001@gmail.com', '09068604584', 'jaafar');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  `price` int(50) NOT NULL,
  `reference` varchar(20) NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `fullname`, `email`, `phonenumber`, `price`, `reference`, `created_on`) VALUES
(1, 'musa sabo', 'musasabogumel@gmsil.com', '09074233199', 2000, '0', '2023-08-20'),
(2, 'musa sabo', 'musasabogumel@gmail.com', '09074233199', 2000, '0', '2023-08-20'),
(3, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 2000, '0', '2023-08-20'),
(4, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 2000, '0', '2023-08-20'),
(5, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, '0', '2023-08-20'),
(6, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, '0', '2023-08-20'),
(7, 'kabiru gambo', 'kabiru123@gmail.com', '08030749342', 2000, '0', '2023-08-20'),
(8, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, '0', '2023-08-21'),
(9, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, '0', '2023-08-21'),
(10, 'Aliyu Sallau', 'aliyuibrahimsallau@gmail.com', '07066218753', 2000, '0', '2023-08-21'),
(11, 'muhammad musa', 'jaafarsallau2001@gmail.com', '09068604584', 2000, 'ref_273370367', '2023-08-21'),
(12, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_459078610', '2023-08-21'),
(13, 'musa sabo', 'jaafarsallau2001@gmail.com', '09068604584', 2000, 'ref_158566425', '2023-08-21'),
(14, 'adamu goni', 'jaafarsallau2001@gmail.com', '08030749342', 2000, 'ref_299431882', '2023-08-21'),
(15, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, 'ref_99852025', '2023-08-21'),
(16, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 20000, 'ref_115995145', '2023-08-21'),
(17, 'Yushau elsunais', 'yelsunais2014@gmail.com', '08030749342', 2000, 'ref_623779072', '2023-08-21'),
(18, 'maryam talba', 'jaafarsallau2001@gmail.com', '08030749342', 10000, 'ref_897986009', '2023-08-22'),
(19, 'No name set', 'customer_email@gmail.com', '+234 123 456 7890', 2000, 'ref_615713091', '2023-08-23'),
(20, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_814810213', '2023-08-23'),
(21, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, 'ref_945647994', '2023-08-23'),
(22, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_406116347', '2023-08-29'),
(23, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_907456218', '2023-08-30'),
(24, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_921263039', '2023-08-30'),
(25, 'jaafar sallau', 'maryamtalba@gmail.com', '09068604584', 10000, 'ref_417087075', '2023-08-30'),
(26, 'musa sabo', 'jaafarsallau2001@gmail.com', '09068604584', 10000, 'ref_689079154', '2023-08-31'),
(27, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, 'ref_529340172', '2023-09-01'),
(28, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_52891907', '2023-09-01'),
(29, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_612677599', '2023-09-03'),
(30, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_993206894', '2023-10-03'),
(31, 'hajara nura', 'hajara123@gmail.com', '07050700903', 4000, 'ref_886677005', '2023-10-03'),
(32, 'hajara nura', 'hajara123@gmail.com', '07050700903', 4000, 'ref_269667782', '2023-10-03'),
(33, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 4000, 'ref_278214035', '2023-10-03'),
(34, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', 8000, 'ref_105189612', '2023-10-04'),
(35, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 12000, 'ref_79511102', '2023-10-04'),
(36, 'sallau adamu', 'sallaukowanaka1@gmail.com', '08030749342', 6000, 'ref_782739682', '2023-10-04'),
(37, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 10000, 'ref_959470838', '2023-10-04'),
(38, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 4000, 'ref_501037327', '2023-10-05'),
(39, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_889501899', '2023-10-05'),
(40, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_685593243', '2023-10-05'),
(41, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_353005405', '2023-10-06'),
(42, 'maryam talba', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_531776027', '2023-10-06'),
(43, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_54426105', '2023-10-06'),
(44, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 10000, 'ref_118911594', '2023-10-06'),
(45, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 12000, 'ref_510235158', '2023-10-06'),
(46, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 12000, 'ref_147269506', '2023-10-06'),
(47, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 12000, 'ref_68839878', '2023-10-06'),
(48, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 12000, 'ref_256594309', '2023-10-06'),
(49, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_359667193', '2023-10-06'),
(50, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 2000, 'ref_982522370', '2023-10-06'),
(51, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_487032704', '2023-10-06'),
(52, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_684805530', '2023-10-06'),
(53, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_133407871', '2023-10-10'),
(54, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_866021322', '2023-10-10'),
(55, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_820400055', '2023-10-10'),
(56, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_551769740', '2023-10-10'),
(57, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_165280789', '2023-10-10'),
(58, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_332114532', '2023-10-10'),
(59, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 6000, 'ref_24237960', '2023-10-11'),
(60, 'Kabirru Gambo ', 'sallaukowanaka1@gmail.com', '07066218753', 8000, 'ref_146973711', '2023-10-11'),
(61, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '07066218753', 10000, 'ref_701764221', '2023-10-11'),
(62, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 8000, 'ref_407953887', '2023-10-13'),
(63, 'jaafar sallau', 'jaafarsallau2001@gmail.com', '09068604584', 4000, 'ref_110765805', '2023-10-14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(40) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `phonenumber`, `address`, `state`, `city`, `password`) VALUES
(1, 'jaafar2001', 'jaafarsallau2001@gmail.com', 'jaafar2001', '09068604584', 'Bulabulin ward', 'Yobe state', 'Nguru', '$2y$10$EvzUqT.jxeYC9O9vxFLX.O47pkPwDJo.Mm/9Fw/ibNkexTTh9J53S'),
(2, 'aliyu2018', 'aliyusallau2018@gmail.com', 'aliyu2018', '07066218753', 'HAUSARI WARD', 'YOBE STATE', 'NGURU', '$2y$10$kzGb8oUKUitjzbKDDzBhCuiEvF.6Bk/rjeuMpi6wU7/BnnDN7UiFa'),
(3, 'maryam2009', 'maryamtalba@gmail.com', 'maryam2009', '09068604584', 'HAUSARI WARD', 'YOBE STATE', 'NGURU', '$2y$10$tUuYcMgn.Qnferw6lG4FrOSIcmdlsQpDW0Ik.V2wiH0lgibbV2K7q'),
(4, 'musa1234', 'musasabogumel@gmsil.com', 'musa1234', '09074233199', 'OLD BRA BRA DAMATURU', 'YOBE STATE', 'DAMATURU', '$2y$10$fWlc4UTvPHBXA8QxcD6G5.6Wv3Wfw3tZDbr3JYFQ62GpGCIMER7re'),
(5, 'elsunais2014', 'yelsunais2014@gmail.com', 'elsunais2014', '07050700903', 'LOWCOST NGURU', 'YOBE STATE', 'NGURU', '$2y$10$rDwoXsAxr27Qw3OdB.7ky.ogP0jytDBA.iJ5TJvpLu75kc9WGYao6'),
(6, 'ahmed123', 'ahmedtijjaniyerima@gmail.com', 'ahmed123', '07035939216', 'YOBE STATE UNIVERSITY', 'YOBE STATE', 'DAMATURU', '$2y$10$lZPFsTq/OAvYv6hziWJplOr4r1GFPKG0w1MSG8B7n2wwhY.InK.yq'),
(7, 'jamila123', 'kabiru123@gmail.com', 'jamila123', '07066218753', 'HAUSARI WARD', 'YOBE STATE', 'NGURU', '$2y$10$CYZIBckEcQMNq07.h0/PduToLNWROc/a7vV.F3T8X54UIqYLCN/yG'),
(8, 'isah123', 'aliyuisah@gmail.com', 'isah123', '08030749342', 'LOWCOST NGURU', 'Yobe state', 'Nguru', '$2y$10$dC.rrPEAfQLHTl49nFW6mOmGyQlxLHLIR5RzsvzjgiPRuE0SPoVRS'),
(9, 'alhassan123', 'alhassanjibrin@gmail.com', 'alhassan123', '08030749342', 'LOWCOST NGURU', 'YOBE STATE', 'NGURU', '$2y$10$I9vHU6r4RaSNEG/LOIgfAe8tl36PgKgGGB4PWRvjFqWFekE/Gu0/e'),
(10, 'AL AMEEN MANSUR ', 'alameenmansur123@gmail.com', 'alameen123', '08030749342', 'Bulabulin ward', 'Yobe state', 'Nguru', '$2y$10$8B/80v2zJiSSLTUyUlXltuKUnVakyL5T4Lb.52/mok.npfqF2yk2a'),
(11, 'HUSSAINI IBRAHIM', 'hussainiibrahim@gmial.com', 'hussaini123', '08030749342', 'HAUSARI WARD', 'Yobe state', 'Nguru', '$2y$10$bdrNOCqlTDsW42cc5Q1Qu.XeYCPC1YVnMRLvv/pflJb8M3lM.tQ32'),
(12, 'usman sallau', 'usmansallau@gmail.com', 'usman123', '07066218753', 'Bulabulin ward', 'Yobe state', 'Nguru', '$2y$10$8TxHKjPb1R31isWaE6OceuUl10nnIRkvYryWKY29..otkUtoCjPN6'),
(13, 'kabiru gambo', 'jaafaribrahimsallau@gmail.com', 'lawan231', '09074233199', 'Bulabulin ward', 'YOBE STATE', 'NGURU', '$2y$10$Z8U3OjWijBqhO5tc1Ni5nuIxgeHOBN0ObmGarvNDDzLPQ0RIZsO6O'),
(16, 'jaafar sallau', 'sallaukowanaka1@gmail.com', 'lawan333', '09068604584', 'bulabulin ward', 'yobe state', 'nguru', '$2y$10$p94v6NUS/wwQX4Hcyz/.WeZ8/tl87oQqUXH2.WQcWh2r1hUpnvDUy'),
(17, 'jaafar sallau', 'nuhu22@gmail.com', 'nuhu000', '08030749342', 'bulabulin ward', 'yobe state', 'nguru', '$2y$10$Q4s2YUj9PfKxv7.7OVKE/OzZOsEMJ36.0PIZ5HDyy1a6nffNeqXgO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id`) REFERENCES `payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
