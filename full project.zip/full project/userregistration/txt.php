<?php
    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

            <div class="card mt-5">
                <div class="card-header">
                    <h4 class="display-4">Ticket</h4>
                </div>
                <div class="card-body">

                           
                
                    <table class="table tyable-bordered">
                        <thead>
                            <tr>
                                <tr>
                                    <th>ID</th>
                                    <th>FULLNAME</th>
                                    <th>EMAIL</th>
                                    <th>PHONENUMBER</th>
                                    <th>DATE</th>
                                    <th>TIME</th>
                                    <th>FROM</th>
                                    <th>TO</th>
                                    <th>TICKET</th>
                                </tr>
                            </tr>
                        </thead>
                        <tbody>
</body>
</html>
<?php
    
$conn = mysqli_connect("localhost", "root", "", "userregistration");

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Define the query and desired_id
$query = "SELECT id, fullname,email,phonenumber, _date, _time, _from, _to, ticket FROM booking WHERE id = ?";
 // Change this to the desired ID you want to query
    $select = mysqli_query($conn,"SELECT MAX(id) AS id FROM booking") or die (mysqli_error($conn));
    $row = mysqli_fetch_assoc($select);
    $id = $row['id'];

$stmt = mysqli_prepare($conn, $query);

if (!$stmt) {
    die("Error: " . mysqli_error($conn)); 
}

mysqli_stmt_bind_param($stmt, "i", $id); 

if (!mysqli_stmt_execute($stmt)) {
    die("Error: " . mysqli_stmt_error($stmt));
}

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Output the data here
        
        ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['fullname']; ?></td>
            <td><?= $row['email']; ?></td>
            <td><?= $row['phonenumber']; ?></td>
            <td><?= $row['_date']; ?></td>
            <td><?= $row['_time']; ?></td>
            <td><?= $row['_from']; ?></td>
            <td><?= $row['_to']; ?></td>
            <td><?= $row['ticket']; ?></td>
        </tr>
 <?php
    }
} else {
    ?>
    <tr>
        <td colspan="9">No Record Found</td>
    </tr>
    <?php
}

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);

?>
