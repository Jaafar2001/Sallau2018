<?php 
    include_once('header.php');

?>

<section class="signup-form">
      <div>
    <form class="row g-3 ms-5" action ="includes/login.inc.php" method="post">
        <div class="login">
        
        </div>
        <h2 class="display-6 text-center mt-5">Log In</h2>
    <div class="col-md-3 ">
    <label for="username" class="form-label">Username/Email</label>
    <input type="fullname" class="form-control" id="username" name="username">
  </div>

  <div class="col-lg-3 ms-6 ">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  </div>
  <div class="col-12 text-center">
    <button type="submit" class="btn btn-primary" name="submit">Log In</button>
  </div>
</form>
</div>
<?php 
  if(isset($_GET["error"])) {
    if ($_GET ["error"] == "emptyinput"){
      echo "<p>Fill all the fields</p>";

    }


   else if ($_GET["error"] == "wronglogin"){
      echo "<p>Incorrect Login Information!</p>";

    }

  }
    
  ?>

</section>



<?php 
    include_once('footer.php');

?>




