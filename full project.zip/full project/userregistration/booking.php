
<?php


?>
 <section class =index-intro>
    <?php 
                    
                    
                    if (isset($_SESSION["username"])) {
                        
                   
                        echo "<p>Yello welcome ".$_SESSION["username"] . "</p>";     

                    } 
            
            ?>
    </section>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">

</head>
<body>
    <form action="includes/booking.inc.php" method="post">
<section id="reviews">
            <div class="container-lg">
                <div class="text-center my-5">
                    <h5>working with forms</h5>
                    <p class="lead">is very vital</p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <form>
                            <label for="fullname" class="form-label">Fullname:</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i> 
                                </span>
                                <input type="text" class="form-control" id="fullname" name="fullname" required>
                                <span class="input-group-text">
                                    <span class="tt" data-bs-placement="top">
                                        <i class="bi bi-vinyl"></i> 
                                    </span>
                                </span>
                            </div>
                            
                            <label for="email" class="form-label mt-3">Email Address:</label>
                             <div class="input-group">
                                <input type="text" class="form-control" id="email" name="email" placeholder="e.g sallau@example.com" required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>   
                            
                            
                            <label for="phonenumber" class="form-label mt-3">Phone Number:</label>
                             <div class="input-group">
                                <input type="text" class="form-control" id="phonenumber" name="phonenumber" required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>    

                            
                            <label for="date" class="form-label mt-3">Booking Date:</label>
                             <div class="input-group">
                                <input type="date" class="form-control" id="date" name="date" required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>    

                            
                            <label for="time" class="form-label mt-3">Booking Time:</label>
                             <div class="input-group">
                                <input type="time" class="form-control" id="time" name="time"  required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>    


                            
                            <label for="from" class="form-label mt-3">From:</label>
                             <div class="input-group">
                                <input type="text" class="form-control" id="from" name="from" required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>    


                            
                            <label for="to" class="form-label mt-3">To:</label>
                             <div class="input-group">
                                <input type="text" class="form-control" id="to" name="to" required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>    


                            
                            <label for="ticket" class="form-label mt-3">Number of Ticket:</label>
                             <div class="input-group">
                                <input type="number" class="form-control" id="ticket" name="ticket" required>
                                <span class="input-group-text">
                                    <i class="bi bi-vinyl"></i>   
                                </span>
                            </div>   

                            <div class="col-12 text-center">
                           
    <button type="submit" class="btn btn-primary text-center mt-3" name="submit">Reserve</button>
  </div>
                            
       
</form>

<?php
    if(isset($_GET["error"])) {
        if ($_GET ["error"] == "emptyinput"){
            echo "<p>Fill all the fields</p>";
        }

        else if ($_GET ["error"] == "none"){
            echo "<p>You have signed up!</p>";
        }
    }
    include_once('footer.php');
?>