<?php 
    include_once('header.php');

?>

<section class="signup-form">
    <div>
    <form class="row g-3 ms-3 me-3" action ="includes/signup.inc.php" method="post">
        <div class="Signup mt-10">
        
        </div>
        <h2 class="display-6 text-center mt-5">Sign up</h2>
    <div class="col-md-3">
    <label for="fullname" class="form-label">Fullname</label>
    <input type="fullname" class="form-control" id="fullname" name="name">
  </div>
  <div class="col-md-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" name="email">
  </div>
  <div class="col-md-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" id="username" placeholder="Jaafar2001" name="username">
  </div>
  <div class="col-md-3">
    <label for="phonenumber" class="form-label">Phone Number</label>
    <input type="text" class="form-control" id="phonenumber" placeholder="09068604584" name="phonenumber">
  </div>
  <div class="col-md-3">
    <label for="address" class="form-label">Address</label>
    <input type="text" class="form-control" id="address" placeholder="Bulabulin ward" name="address">
  </div>
  <div class="col-sm-3">
    <label for="state" class="form-label">State</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Yobe State" name="state">
  </div>
  <div class="col-md-3">
    <label for="city" class="form-label">City</label>
    <input type="text" class="form-control" id="city" name="city">
  </div>
  <div class="col-md-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  <div class="col-md-3">
    <label for="rpassword" class="form-label">R-Password</label>
    <input type="password" class="form-control" id="rpassword" name="rpassword">
  </div> 
  <div class="col-12 text-center">
    <button type="submit" class="btn btn-primary text-center" name="submit">Sign Up</button>
  </div>
</form>
</div>
<?php 
  if(isset($_GET["error"])) {
    if ($_GET ["error"] == "emptyinput"){
      echo "<p>Fill all the fields</p>";

    }
    

   else if ($_GET ["error"] == "invalidusername"){
      echo "<p>Choose a proper username</p>";

    }

    else if ($_GET ["error"] == "invalidemail"){
      echo "<p>Choose a proper email</p>";

    }

    else if ($_GET ["error"] == "passworddoesnotmatch"){
      echo "<p>Password does not match</p>";

    }

    else if ($_GET ["error"] == "stmtfailed"){
      echo "<p>Something went wrong, try agian!</p>";

    }

    else if ($_GET ["error"] == "usernameoremailistaken"){
      echo "<p>Username or email already taken!</p>";

    }

    else if ($_GET ["error"] == "none"){
      echo "<p>You have signed up!</p>";

    }

  }
    
  ?>
</section>

  


<?php 
    include_once('footer.php');

?>




