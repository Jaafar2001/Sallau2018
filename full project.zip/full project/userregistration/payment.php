<!DOCTYPE html>

<html lang="en">
<head>
    <title>Payment</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">

</head>
<body>
    <?php 
        //Get values set by function.inc.php or return default values
        $fullName = isset($_GET['name']) ? $_GET['name'] : "No name set";
        $email    = isset($_GET['email']) ? $_GET['email'] : "customer_email@gmail.com";
        $phone    = isset($_GET['phone']) ? $_GET['phone'] : "+234 123 456 7890";  
        $ticket   = isset($_GET['ticket']) ? $_GET['ticket'] : 1;
    ?>
    <div id="success-div" class="alert alert-info col-8 mx-auto p-5 mt-5 d-none h-20">
        <h3>You have successfully paid for the booking</h3>
        <a href="ticket.php" class="btn btn-primary" target="blank">Download your ticket!</a>
    </div>
    
    <div id="payprompt" class="col-8 mx-auto shadow p-5 mt-5">
        
        <h4>
            Hello <?php echo $fullName ?>,
        </h4>
        <p>
            You have successfully reserved your booking, click the button
            below to make your payment for
            <b><?php echo $ticket ?></b>ticket(s)
        </p>

        <button id="payButton" class="btn btn-primary" onclick="payWithPaystack()">Make payment</button>
    </div>

    
   
    <script src="https://js.paystack.co/v1/inline.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>

        function payWithPaystack(){

            //Variables for payment and database
            var Name    = '<?php echo $fullName ?>';
            var Email   = '<?php echo $email ?>';
            var Phone   = '<?php echo $phone ?>';
            var ticket  = '<?php echo $ticket?>';
            var Ref     = 'ref_'+Math.floor((Math.random() * 1000000000) + 1)// generates unique reference num
            var Amount  = 2000 * ticket;
            var handler = PaystackPop.setup({
                
              key:  'pk_test_e5e3ee145006ff9462332deec3f9675a860aa4c2',  // TEST KEY
              email: Email,
              amount: Amount + '00', // two zeros must be added to actual amount
              ref: Ref, 
              metadata: {
                 custom_fields: [
                    {
                        display_name: "Phone Number",
                        variable_name: "phone_number",
                        value: Phone
                    }
                 ]
              },
              callback: function(response){
                //Payment is successful, save the payment detail to db using ajax
                   $.ajax({
                      type: "POST",
                      url: "includes/save_payment.php",
                      data: {fullname: Name, email: Email, phone: Phone, price: Amount, ref: Ref},
                      success: function(response) {
                          response = JSON.parse(response);
                          if (response.result == 'success'){ // payment detail is saved
                            $('#success-div').removeClass('d-none'); // show success
                            $('#payprompt').addClass('d-none'); // hide payprompt
                          }else{
                              alert('Payment failed\n'+response);
                          }
                      }
                  }); 
              },
              onClose: function(){
                  alert('window closed');
              }
            });
            handler.openIframe();
        }
    </script>


</body>
</html>
