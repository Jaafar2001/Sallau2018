<?php 
    include_once('header.php');

?>
   

                    
    <section id="intro">
        <div class="container-lg  mt-4">
            <div class="row align-center justify-content-center mb-10">
                <div class="col-md-5 text-center col-md-start">
                    <h2 class="display-2">Welcome To</h2>
                    <h2 class="display-5">National Association of Road Transport Owners (NARTO)</h2>
                    <p class="lead my-4">Your Reliable Transport Company</p>
                    <a href="#sidebar" class=" btn btn-info d-block mt-3" data-bs-toggle="offcanvas" role="button" aria-controls="sidebar">
                            Read before you reserved!
                     </a>

                </div>
                <div class="col-md-5 text-center d-none d-md-block">
                    <img class="img-fluid" src="jaafar.jpeg" alt="logo">
                </div>
            </div>
        </div>
    </section>
   
    <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebar" aria-labelledby="sidebar-label">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="sidebar-label">Read the </h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="close">]
                </button>
            </div>
            <div class="offcanvas-modal">
                <p>
                   Follow the following instruction to reserve your ticket in a successful manner!
                </p>
                <p class="lead text-decoration-underline">How to sign up a new account</p>
                <p>1. fill all the necessary information</p>
                <p>2. each account should use a verified email and username</p>
                <p>3. use a secured password </p>

                <p class="lead text-decoration-underline">How to login</p>
                <p>1. use either email or username to login</p>
                <p>2. use your secured password</p>
                <!----offcanvas dropdown--->
                <div class="dropdown mt-3">
                    <button class="btn btn-secondary dropdown-toggle ms-5 text-center" type="button" id="book-dropdown" data-bs-toggle="dropdown">
                        Menu
                    </button>
                    <ul class="dropdown-menu" aria-labelledby=" book-dropdown">
                        <li><a href="index.php" class="dropdown-item">HOME</a></li>
                        <li><a href="aboutus.php" class="dropdown-item">ABOUT US</a></li>
                        <li><a href="contact.php" class="dropdown-item">CONTACT US</a></li>
                        <li><a href="signup.php" class="dropdown-item">SIGN UP</a></li>
                        <li><a href="login.php" class="dropdown-item">LOG IN</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
      

<?php 
    include_once('footer.php');

?>




