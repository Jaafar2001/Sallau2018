
<?php
require_once 'vendor/autoload.php';

use Dompdf\Dompdf;

$conn = mysqli_connect("localhost", "root", "", "userregistration");

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Define the query and desired_id
$query = "SELECT id, fullname,email,phonenumber, _date, _time, _from, _to, ticket FROM booking WHERE id = ?";
// Change this to the desired ID you want to query
$select = mysqli_query($conn,"SELECT MAX(id) AS id FROM booking") or die (mysqli_error($conn));
$row = mysqli_fetch_assoc($select);
$id = $row['id'];

$stmt = mysqli_prepare($conn, $query);

if (!$stmt) {
    die("Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $id);

if (!mysqli_stmt_execute($stmt)) {
    die("Error: " . mysqli_stmt_error($stmt));
}

$result = mysqli_stmt_get_result($stmt);

// Create a new PDF instance
$dompdf = new Dompdf();
$html = '<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket</title>
    <style>
        img{
            width = 40px;
            height = 40px;
        }

        h2{
            font-family: Verdena, Geneva, Tahoma, sans-serif;
            text-align: center;
        }

    table{
        width:100%;
        border-collapse: collapse;
        font-family: Arial, Helvetica, sans-serif;
    }
        th, td{
            border: 1px solid #000;
            padding : 8px;
            text-align: left;
        }
    </style></head><body><div class = "container"><table>
</head>
<body>
                 
                <h2>TICKET</h2>
               
                        <thead>
                            <tr>
                                <tr>
                                    <th>ID</th>
                                    <th>FULLNAME</th>
                                    <th>EMAIL</th>
                                    <th>PHONENUMBER</th>
                                    <th>DATE</th>
                                    <th>TIME</th>
                                    <th>FROM</th>
                                    <th>TO</th>
                                    <th>TICKET</th>
                                </tr>
                            </tr>
                        </thead>
                        <tbody>'; // Your existing HTML
while ($row = mysqli_fetch_assoc($result)) {
    // Add data to your HTML
    
    $html .= ' <td>' . $row['id'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['fullname'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['email'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['phonenumber'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['_date'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['_time'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['_from'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['_to'] . '</td>...'; // Add your data as needed
    $html .= '<td>' . $row['ticket'] . '</td>...'; // Add your data as needed
}

$html .= '</tbody>
</table>
</div>
</body>
</html>';

// add css for table borders

// Load the HTML content into dompdf
$dompdf->loadHtml($html);

// Set paper size and rendering options
$dompdf->setPaper('A4', 'landscape');

// Render the PDF
$dompdf->render();

// Output the generated PDF
$dompdf->stream('ticket.pdf', ['Attachment'=> 0]);

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
