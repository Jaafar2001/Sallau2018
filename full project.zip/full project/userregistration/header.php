<?php 
session_start();




?>
                



<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Userregistration</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
     crossorigin="anonymous">
</head>
<style>
        #intro{
            padding: 60px 0;
        }
        p{
            text-align:center;
            color:red;
            font-size:20px;
            
        }
    </style>
<body>
    <!---navbar-->
    <nav class="navbar fixed-top navbar-expand-sm navbar-light "> 
        <div class="container-lg">
            <a href="#intro" class="navbar-brand">
                <span class="text-secondary fw-bold">
                    <img src="car.png" alt="" width=40 height=40>
                    National Asociation of Road Transport Owners 
                    
                </span>
            </a>
            <!----toggler button for mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main-nav" aria-controls="main-nav" aria-expanded="false"
            aria-label="toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end align-center" id="main-nav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">HOME</a>
                </li>
                <li class="nav-item">
                    <a href="aboutus.php" class="nav-link">ABOUT US</a>
                </li>
                <li class="nav-item">
                    <a href="contact.php" class="nav-link">CONTACT US</a>
                </li>
                <li class ="nav-item">
                    <a href="signup.php" class="nav-link">SIGN UP</a>
                </li>
                <li class ="nav-item">
                    <a href="login.php" class="nav-link">LOGIN</a>
                </li>
                    <?php 
                    
                    
                            if (isset($_SESSION["username"])) {
                                
                                
                                echo "<li><a href='includes/logout.inc.php'>Log out </a></li>";

                            } else
                            
                            {
                                header ("location ../index.php");
                            }
                    
                    ?>
                    
            </ul>
        </div>
        </div>
    </nav>