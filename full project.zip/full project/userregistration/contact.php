<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
</head>
<body>
<form action="includes/contact.inc.php" method="post">
<section id="reviews">
            <div class="container-lg">
                <div class="text-center my-5">
                    <h5>working with forms</h5>
                    <p class="lead">is very vital</p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <form>
                            <label for="fullname" class="form-label">Fullname:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="fullname" name="fullname" required>
                            </div>
                            
                            <label for="email" class="form-label mt-3">Email Address:</label>
                             <div class="input-group">
                                <input type="text" class="form-control" id="email" name="email" placeholder="e.g sallau@example.com" required>
                                
                            </div>   
                            
                            
                            <label for="phonenumber" class="form-label mt-3">Phone Number:</label>
                             <div class="input-group">
                                <input type="text" class="form-control" id="phonenumber" name="phonenumber" required>
                                
                            </div>    
                            <div class="form-floating">
                            <textarea id="Usermessage" class="form-control mt-3" name="Usermessage" style="height: 140px;"></textarea>
                            <label for="Usermessage" >Enter your complain</label>
                </div>
                <div class="col-12 text-center">
                           
                           <button type="submit" class="btn btn-primary text-center mt-3" name="submit">Submit</button>
                         </div>
</form>
</body>
</html>
<?php



?>
