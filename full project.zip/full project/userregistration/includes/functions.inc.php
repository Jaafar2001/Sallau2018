<?php 

function emptyBooking($fullname, $email,  $phonenumber, $date, $time, $from, $to, $ticket){

    $result;
    
    if (empty($name) || empty($email) || empty($phonenumber) || empty($date) || empty($time) || empty($from) || empty($to) || empty($ticket)) {
    
        $result = false;
    }
    
    else 
    {
        $result = true;
    
    }
    
    return $result;
}

function createBooking($conn, $fullname, $email, $phonenumber, $date, $time, $from, $to, $ticket){
            
    $sql = "INSERT INTO booking(fullname, email, phonenumber, _date, _time, _from, _to, ticket) VALUES(?,?,?,?,?,?,?,?)";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
    echo mysqli_error($conn);
    header("location: ../booking.php?error=stmtfailed");
    exit();
    }
        
    mysqli_stmt_bind_param($stmt, "ssssssss", $fullname, $email,  $phonenumber, $date, $time, $from, $to, $ticket);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close ($stmt); 

    // At this point, everything is ok, go to payment page
    header("location: ../payment.php?email=".$email."&phone=".$phonenumber."&name=".$fullname."&ticket=".$ticket);
    //header("location: ../booking.php?success=1");
    exit();
}


    function emptyInputSignup($name, $email, $username, $phonenumber, $address, $state, $city, $password, $rpassword){

        $result;

        if (empty($name) || empty($email) || empty($username) || empty($phonenumber) || empty($address) || empty($state) || empty($city) || empty($password) ||empty($rpassword)) {

            $result = true;
        }

        else 
        {
            $result = false;

        }

        return $result;
    }




    function invalidusername($username){

        $result;

        if (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {

            $result = true;
        }

        else 
        {
            $result = false;
            
        }

        return $result;
    }


    function invalidemail($email){

        $result;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $result = true;
        }

        else 
        {
            $result = false;
            
        }

        return $result;
    }


    function passwordMatch($password, $rpassword){

        $result;

        if ($password !== $rpassword) {

            $result = true;
        }

        else 
        {
            $result = false;
            
        }

        return $result;
    }


    function usernameExists($conn, $username, $email){

       $sql = "SELECT * FROM users WHERE username = ? OR email = ?;";
       $stmt = mysqli_stmt_init($conn);
       if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../signup.php?error=stmtfailed");
        exit();
       }

       mysqli_stmt_bind_param($stmt, "ss", $username, $email);
       mysqli_stmt_execute($stmt);

       $resultData = mysqli_stmt_get_result($stmt);

       if ($row = mysqli_fetch_assoc($resultData)) {
         return $row;
       }
       else {
        $result = false;
        return $result;
       }

       mysqli_stmt_close ($stmt);

    }

    
    function createUser($conn, $name, $email, $username, $phonenumber, $address, $state, $city, $password){

        $sql = "INSERT INTO users(name, email, username, phonenumber, address, state, city, password) VALUES(?,?,?,?,?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
         header("location: ../signup.php?error=stmtfailed");
         exit();
        }

        $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
 
        mysqli_stmt_bind_param($stmt, "ssssssss", $name, $email, $username, $phonenumber, $address, $state, $city, $hashedpassword);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close ($stmt);
 
        header("location: ../signup.php?error=none");
         exit();
     }


     
    
     function emptyInputLogin($username, $password,){

        $result;

        if (empty($username) ||  empty($password)) {

            $result = true;
        }

        else 
        {
            $result = false;

        }

        return $result;
    }

    function loginUser($conn, $username, $password) {
        $usernameExists = usernameExists($conn, $username, $username);
        
        if ($usernameExists === false) {
            header ("location ../login.php?error=wronglogin");
            exit();
        }

        $passwordHashed = $usernameExists["password"];
        $checkpassword  = password_verify($password, $passwordHashed);

        if ($checkpassword === false) {
            header ("location: ../login.php?error=wronglogin");
            exit();
        }

        else if ($checkpassword === true){
            session_start();
            $_SESSION["id"]         = $usernameExists["id"];
            $_SESSION["username"]   = $usernameExists["username"];
            header ("location: ../booking.php");
            exit();
        }
    }
    
    function emptyContact($fullname, $email,  $phonenumber, $Usermessage){

        $result;
        
        if (empty($fullname) || empty($email) || empty($phonenumber) || empty($Usermessage)) {
        
            $result = true;
        }
        
        else 
        {
            $result = false;
        
        }
        
        return $result;
    }
    
    function createContact($conn, $fullname, $email, $phonenumber, $Usermessage){
            
        $sql = "INSERT INTO contact(fullname, email, phonenumber, Usermessage) VALUES(?,?,?,?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
        echo mysqli_error($conn);
        header("location: ../contact.php?error=stmtfailed");
        exit();
        }
            
        mysqli_stmt_bind_param($stmt, "ssss", $fullname, $email,  $phonenumber, $Usermessage);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close ($stmt); 
        exit();
    }
    
    

?>





