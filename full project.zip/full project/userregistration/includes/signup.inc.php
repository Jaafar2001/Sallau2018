<?php 



if (isset($_POST['submit'])) {
    
    $name               = $_POST['name'];
    $email              = $_POST['email'];
    $username           = $_POST['username'];
    $phonenumber        = $_POST['phonenumber'];
    $address            = $_POST['address'];
    $state              = $_POST['state'];
    $city               = $_POST['city'];
    $password           = $_POST['password'];
    $rpassword          = $_POST['rpassword'];


    require_once('dbh.inc.php');
    require_once('functions.inc.php');

    if (emptyInputSignup($name, $email, $username, $phonenumber,$address,$state,$city, $password,$rpassword) !== false) {
        header("location: ../signup.php?error=emptyinput");
        exit();
    }

    if (invalidusername($username) !== false) {
        header("location: ../signup.php?error=invalidusername");
        exit();
    }

    


    if (invalidemail($email) !== false) {
        header("location: ../signup.php?error=invalidemail");
        exit();
    }

    if (passwordMatch($password, $rpassword) !== false) {
        header("location: ../signup.php?error=passworddoesnotmatch");
        exit();
    }

    if (usernameExists($conn, $username, $email) !== false) {
        header("location: ../signup.php?error=usernameoremailistaken");
        exit();
    }

    createUser($conn, $name, $email, $username, $phonenumber, $address, $state, $city, $password);


} 

else {
    header("location:  .../signup.php");
    exit();
}