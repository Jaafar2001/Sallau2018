<?php
require_once('dbh.inc.php');
require('functions.inc.php');

if (isset($_POST['submit'])) {
    
    $fullname         =  mysqli_real_escape_string($conn, $_POST['fullname']);
    $email            =  mysqli_real_escape_string($conn, $_POST['email']);
    $phonenumber      =  mysqli_real_escape_string($conn, $_POST['phonenumber']);
    $date             =  mysqli_real_escape_string($conn, $_POST['date']);
    $time             =  mysqli_real_escape_string($conn, $_POST['time']);
    $from             =  mysqli_real_escape_string($conn, $_POST['from']);
    $to               =  mysqli_real_escape_string($conn, $_POST['to']);
    $ticket           =  mysqli_real_escape_string($conn, $_POST['ticket']);



    if (emptyBooking($fullname, $email, $phonenumber, $date, $time, $from, $to, $ticket) !== false) {
        header("location: ../booking.php?error=emptyinput");
        exit();
    }

    createBooking($conn, $fullname, $email, $phonenumber, $date, $time, $from, $to, $ticket);

} 

else {
    header("location: ../booking.php?error=none");
    exit();
}


