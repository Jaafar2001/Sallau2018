<?php
require_once('dbh.inc.php');

    $response = array();

    $fullname     = $_POST['fullname'];
    $email        = $_POST['email'];
    $phonenumber  = $_POST['phone'];
    $price        = $_POST['price'];
    $ref          = $_POST['ref'];
    $created_on = date('Y-m-d');
            
    $sql = "INSERT INTO payment (fullname, email, phonenumber, price, reference, created_on) VALUES (?,?,?,?,?,?)";
    $stmt = mysqli_stmt_init($conn);
    // If error occurs, return error message to payment.php
    if (!mysqli_stmt_prepare($stmt, $sql)) { 
        $response['result'] = mysqli_error($conn);
        echo json_encode($response);
        exit();
    }
    
    mysqli_stmt_bind_param($stmt, "ssssss", $fullname, $email,  $phonenumber, $price, $ref, $created_on);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close ($stmt);

    // payment is saved, return success to payment.php
    $response['result'] = "success";
    echo json_encode($response);

?>