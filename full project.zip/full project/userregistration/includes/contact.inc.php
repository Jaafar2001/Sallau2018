<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>alert</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
</head>
<body>
        <h1 class="display-5 text-center mt-5">Complain Submitted Successfully!</h1>    

</body>
</html>

<?php
require_once('dbh.inc.php');
require('functions.inc.php');

if (isset($_POST['submit'])) {
    
    $fullname         =  mysqli_real_escape_string($conn, $_POST['fullname']);
    $email            =  mysqli_real_escape_string($conn, $_POST['email']);
    $phonenumber      =  mysqli_real_escape_string($conn, $_POST['phonenumber']);
    $Usermessage      =  mysqli_real_escape_string($conn, $_POST['Usermessage']);


    if (emptyContact($fullname, $email, $phonenumber, $Usermessage) !== false) {
        header("location: ../contact.php?error=emptyinput");
        exit();
    }

    createContact($conn, $fullname, $email, $phonenumber, $Usermessage);

} 

else {
    header("location: ../contact.php?error=none");
    exit();
}
?>



